import roles.Admin;
import roles.User;
import view.Boundary;

import java.util.*;

/**
 * This is the main class that runs the program.
 * @author Renyu Liu
 *
 */
public class Main {
    public static void main(String[] args) {
        // run the program 
    	new Boundary();

    }
}
